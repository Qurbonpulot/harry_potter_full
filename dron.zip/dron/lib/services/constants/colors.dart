import 'package:flutter/material.dart';

abstract class CustomColors {
  static Color darkTeal = Color(0xff16182C);
static Color lightBlue = Color(0xff33BBF5);
static Color white = Color(0xffffffff);
static Color lightTeal = Color(0xff424161);
static Color lightPurple = Color(0xff666590);
static Color blue = Color(0xff0069C7);
static Color teal = Color(0xff58eeff);
static Color black = Color(0xff000000);
static Color tTeal =Color(0xff16183C);
static Color yellow =Colors.yellow;
}