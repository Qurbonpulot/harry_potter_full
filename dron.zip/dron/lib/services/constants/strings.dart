abstract class CustomStrings{
  static String drone= "Drone";
  static String kart= ".Kart";
  static String djiAir= "DJI Air 2S";
  static String getFeel= "Get a feel for what it is like to own DJI Air 2S in advance.";
  static String buyNow= "BUY NOW";
  static String djiMatrice= "DJI Matrice 30 Series";
  static String getFM= "Get a feel for what it is like to own DJI Matice in advance.";
  static String news= "New";
  static String arrivals= "Arrivals";
  static String bestSeller= "Best Seller";
  static String getFeelN=
      "Get a feel for what is like to own DJI Matrica "
      "in advance. A balance of power and portability "
      "delivers higher operational efficiency. With IPss "
      "protection, the M30 can easily handle adverse "
      "weather and temperatures ranging from 20' C ~ 50' C. "
      "The built-in ADS-B receiver provides timely warning "
      "of any incoming crewed aircraft nearby.";
  static String videoQuality = "Video Quality";
  static String n6k = "\n6k 30fps CinemaDNG";
  static String flightTime = "Flight Time";
  static String nA = "\nApprox, \n41 minutes";
  static String maxSpeed = "Max Speed";
  static String n23 = "\n23 m/s, \nMax Speed";
  static String connectivity = "Connectivity";
  static String n7 = "\n7000 m \nControl range";

}