import 'package:flutter/material.dart';

import 'drone.dart';

void main() {
  runApp(const App());
}
