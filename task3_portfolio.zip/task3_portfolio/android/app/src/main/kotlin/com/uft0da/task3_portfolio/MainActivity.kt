package com.uft0da.task3_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
