import 'package:flutter/material.dart';
import 'package:task3/app.dart';

void main() {
  runApp(const MyApp());
}
