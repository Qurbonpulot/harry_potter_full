package com.example.shadows_style

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
