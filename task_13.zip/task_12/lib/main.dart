import 'package:flutter/material.dart';

import 'tesla_app.dart';
void main(){
  runApp(const TeslaApp());
}