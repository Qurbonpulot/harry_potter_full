import 'package:flutter/material.dart';
import 'package:task_12/screens/auto_pilot.dart';
import 'package:task_12/screens/exterior_screen.dart';
import 'package:task_12/screens/interior_page.dart';
import 'package:task_12/screens/performance_screen.dart';
import 'package:task_12/services/constants/colors.dart';
import 'package:task_12/services/constants/fonts.dart';
import 'package:task_12/services/constants/images.dart';
import 'package:task_12/services/constants/strings.dart';

class CarScreen extends StatefulWidget {
  const CarScreen({super.key});

  @override
  State<CarScreen> createState() => _CarScreenState();
}

class _CarScreenState extends State<CarScreen> with TickerProviderStateMixin {
  late TabController controller;
  @override
  void initState() {
    controller = TabController(
      length: 4,
      vsync: this,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /// #main ap bar
      appBar: AppBar(
        /// #back button app bar
        leading: const BackButton(color: CustomColors.oxFF000000),

        /// #letter tesla in app bar
        title: const Image(image: CustomImages.teslaBlack),
        centerTitle: true,

        /// #tab bar
        bottom: TabBar(
          physics: const NeverScrollableScrollPhysics(),
          controller: controller,
          labelPadding: const EdgeInsets.only(right: 5),
          indicatorColor: CustomColors.oxFFD01000,
          unselectedLabelStyle: CustomFonts.styleTab,
          labelColor: CustomColors.oxFF000000,
          labelStyle: CustomFonts.styleTab,
          unselectedLabelColor: CustomColors.oxFF979797,
          onTap: (value) {},
          tabs: const [
            Tab(child: Text(CustomStrings.tabBarText1)),
            Tab(child: Text(CustomStrings.tabBarText2)),
            Tab(child: Text(CustomStrings.tabBarText3)),
            Tab(child: Text(CustomStrings.tabBarText4)),
          ],
        ),
      ),

      body: TabBarView(
        controller: controller,
        children: [
          /// #performance page
          PerformanceScreen(
            function: () {
              controller.animateTo(1);
            },
          ),

          /// # exterior page
          ExteriorScreen(
            function: () {
              controller.animateTo(2);
            },
          ),

          /// # interior page
          InteriorPage(
            function: () {
              controller.animateTo(3);
            },
          ),

          /// #autopilot page
          const AutoPilotPage(),

          ///
        ],
      ),
    );
  }
}
