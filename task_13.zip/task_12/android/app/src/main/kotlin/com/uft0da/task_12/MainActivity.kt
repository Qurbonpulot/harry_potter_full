package com.uft0da.task_12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
