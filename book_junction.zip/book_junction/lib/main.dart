import 'package:book_junction/book_junction_app.dart';
import 'package:flutter/material.dart';
void main(){
  runApp(const BookJunctionApp());
}