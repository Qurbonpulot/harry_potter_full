package com.uft0da.book_junction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
